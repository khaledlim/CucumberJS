const { Before, Given , When, Then} = require('@cucumber/cucumber')
var world = require('./world.js')

Given('I bye drilling tool worth ${int}', function(int) {
    world.x = int
});

Given('I bye the plant worth ${int}', function(int) {
    world.x = world.x + int
});

Then ('Total due amount is ${int}', function(int) {
    console.log(world.x)
});


// npx cucumber-js   (Npx: node apckage execute)